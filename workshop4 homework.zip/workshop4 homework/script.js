"use strict";

// task 1

let mainDiv = document.getElementById("main_wrapper");
mainDiv.classList.add("wrapper");

let myImg = document.createElement("img");
myImg.setAttribute(
  "src",
  "https://cdn.prod.www.spiegel.de/images/1f4ce1a9-0001-0004-0000-000000209910_w960_r1.778_fpx30.47_fpy52.92.jpg"
);
mainDiv.appendChild(myImg);

let myText = document.createElement("h2");
myText.classList.add("title");
myText.innerText = "Image title";
myText.style.fontSize = "30px";
myText.style.color = "red";

mainDiv.appendChild(myText);

// task 2

let mainContent = document.querySelectorAll(".maincontent");

mainContent.forEach((element) => {
  let myParagraph = document.createElement("p");
  myParagraph.classList.add("text");
  myParagraph.innerText = "hello";
  element.appendChild(myParagraph);
});
